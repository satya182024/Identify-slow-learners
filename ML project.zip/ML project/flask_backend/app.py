from flask import Flask, request, jsonify
import numpy as np

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    # Extract features from the received JSON data
    try:
        iq = int(data['IQ'])
        total_score = int(data['Total_Score'])
        learning_preference = data['Learning_Preferences']
        aptitude_score = int(data['Aptitude_Score'])
        cgpa = float(data['CGPA'])
        attendance = float(data['Attendance'])
        participation = data['Participation']
    except (KeyError, ValueError) as e:
        return jsonify({'error': str(e)}), 400

    # Example prediction logic
    threshold = 350
    if total_score < threshold:
        prediction = 'Slow Learner'
    else:
        prediction = 'Not a Slow Learner'

    return jsonify({'prediction': prediction})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)


# from flask import Flask, request, jsonify
# import pandas as pd
# import numpy as np

# app = Flask(__name__)

# # Define a condition for identifying slow learners
# def is_slow_learner(total_score):
#     threshold = 350
#     return total_score < threshold

# @app.route('/predict', methods=['POST'])
# def predict():
#     data = request.get_json()

#     IQ = data['IQ']
#     total_score = data['Total_Score']
#     learning_preferences = data['Learning_Preferences']
#     aptitude_score = data['Aptitude_Score']
#     cgpa = data['CGPA']
#     attendance = data['Attendance']
#     participation = data['Participation']

#     # Perform prediction
#     slow_learner = is_slow_learner(total_score)
    
#     return jsonify({'Slow_learner': int(slow_learner)})

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)


# # from flask import Flask, request, jsonify
# # import pandas as pd
# # import numpy as np

# # app = Flask(__name__)

# # # Define a condition for identifying slow learners
# # def is_slow_learner(total_score):
# #     threshold = 350
# #     return total_score < threshold

# # @app.route('/predict', methods=['POST'])
# # def predict():
# #     data = request.get_json()

# #     IQ = data['IQ']
# #     total_score = data['Total_Score']
# #     learning_preferences = data['Learning_Preferences']
# #     aptitude_score = data['Aptitude_Score']
# #     cgpa = data['CGPA']
# #     attendance = data['Attendance']
# #     participation = data['Participation']

# #     # Perform prediction
# #     slow_learner = is_slow_learner(total_score)
    
# #     return jsonify({'Slow_learner': int(slow_learner)})

# # if __name__ == '__main__':
# #     app.run(debug=True)
